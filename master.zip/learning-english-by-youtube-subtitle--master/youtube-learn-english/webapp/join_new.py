from django.urls import path
from . import views

urlpatterns = [
    path('', views.join_new, name='join_new')
]

