from django.contrib import admin
from .models import Join
from .models import Login
from .models import Gtran

admin.site.register(Join)
admin.site.register(Login)
admin.site.register(Gtran)

# Register your models here.
