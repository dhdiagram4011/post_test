from django.urls import path
from . import views

urlpatterns = [
    path('',views.gtrans_result, name='gtrans_result')
]