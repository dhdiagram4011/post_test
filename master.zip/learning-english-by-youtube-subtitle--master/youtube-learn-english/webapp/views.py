from django.shortcuts import render
from django.shortcuts import redirect
from django.utils import timezone
from .models import Join
from .models import Gtran
from .forms import JoinForm
from .forms import LoginForm
from .forms import GtransForm
from google.cloud import translate
from django.contrib.auth.models import User
from django.contrib.auth.hashers import make_password, check_password
import urllib, http.cookiejar
import urllib.request

import ssl

ssl._create_default_https_context  = ssl._create_unverified_context

def join_list(request):
    #joins = Join.objects.filter(published_date__lte=timezone.now())
    joins = Join.objects.filter('create_date')
    return render(request, 'webapp/join.html', {'joins':joins})

def register(request):
    return render(request, 'webapp/register.html')

def translation(request):
    return render(request, 'webapp/translate.html')


## 로그인
def login(request):
   if request.method == "GET":
        form = LoginForm(request.GET)
        return render(request, 'webapp/login.html', {'form':form})
   elif request.method == "POST":
       form = LoginForm(request.POST)
       name = request.POST.get('name',None)
       password = request.POST.get('password', None)
       post = form.save()

       res_data = {}
       if not (name and password):
           res_data['error'] = '아이디와 패스워드를 정확히 임력하여 주세요'
       else:
           join = Join.objects.get(name=name)
           if check_password(password, join.password):
               request.session['user'] = join.name
               return redirect('webapp/oauth_success.html')
           else:
               res_data['error'] = '비밀번호를 정확히 입력하여 주세요'
       return render(request, 'webapp/login.html', {'form':form}, res_data)
           
        
def res(request):
    return render(request, 'webapp/new_member.html')

def oauth_success(request):
    return render(request, 'webapp/oauth_success.html')



## 회원가입
def join_new(request):
    if request.method == 'GET':
        form = JoinForm(request.GET)
        return render(request, 'webapp/join_new.html', {'form':form})
    elif request.method == "POST":
        form = JoinForm(request.POST)
        post = form.save()
        #author_id = request.user
        name = request.POST.get('name', None)
        email = request.POST.get('email', None)
        password = request.POST.get('password',None)
        post.published_date = timezone.now()
    #return redirect('join_list')
    return render(request, 'webapp/new_member.html')


## 번역할 문장을 입력 후 버튼을 누르면 번역할 문장을 보여줌
def gtrans_template(request):
    if request.method == "GET":
        form = GtransForm(request.GET)
        return render(request, 'webapp/gtrans_msg.html', {'form':form})
    elif request.method == "POST":
        post = form.save()
        asis = request.POST.get('asis',None)
        languages = request.POST.get('languages',None)
        #translate_client = translate.Client()
        #translation = translate_client.translate(asis,target_language=languages)
        post.published_date = timezone.now()
        return redirect('gtrans_result')
        
def gtrans_result(request):
    gtrans = Gtran.objects.filter(published_date__lte=timezone.now()).order_by('-published_date')[:1]
    return render(request, 'webapp/gtrans_result.html', {'gtrans':gtrans})
    
 
# 구글 oauth 로그인
def oauth(request):
    googleid = ''
    password = ''
    context = ssl._create_unverified_context()
    cookie_jar = http.cookiejar.LWPCookieJar()
    opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(cookie_jar))
    urllib.request.install_opener(opener)
    params = urllib.parse.urlencode({"googleid":googleid, "password":password})
    params = params.encode('utf-8')
    opener.open('http://psyched-subset-242903.dhdiagram.com/oauth2callback', params)
    request = urllib.request.Request("https://plus.google.com/explore", params)
    response = opener.open(request)
    
    return redirect('oauth_success')
            
    #if __name__ == '__main__':
    #    google_login()







