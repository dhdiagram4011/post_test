# Create your models here.
# deveoloer : rlaehgud21764011@gmail.com
# title : join

from django.db import models
from django.utils import timezone
#from django import forms
#from django.contrib.auth.hashers import check_password
#from google.cloud import translate

class Join(models.Model):
    #author = models.ForeignKey('auth.User', on_delete= models.CASCADE)
    name = models.CharField(max_length=200)
    password = models.CharField(max_length=200)
    email = models.EmailField(max_length=200)
    published_date = models.DateTimeField(blank=True, null=True)

    def publish(self):
        self.published_date = timezone.now()
        self.save()

class Login(models.Model):
    name = models.CharField(max_length=200)
    password = models.CharField(max_length=200)

    # new youtube translate web ui 
class Gtran(models.Model):
    asis = models.TextField(max_length=5000)
    languages = models.CharField(max_length=200) 
    published_date = models.DateTimeField(blank=True, null=True)

    #def publish(self):
    #    self.published_date = timezone.now()
    #    self.save()

def __str__(self):
    return self.email
