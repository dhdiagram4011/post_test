from django.urls import path
from . import views

urlpatterns = [
path('', views.oauth_success,name='oauth_success')
]