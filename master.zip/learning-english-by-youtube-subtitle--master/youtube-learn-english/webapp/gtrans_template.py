from django.urls import path
from . import views


urlpatterns = [
    #path('',views.google_trans, name='google_trans')
    path('',views.gtrans_template, name='gtrans_template')
]