from django.urls import path
from . import views

urlpatterns  = [
    path('', views.join_list, name='join_list'),
    path('', views.join_new, name='join_new'),
    path('', views.gtrans_result, name='gtrans_result'),
    path('', views.login, name='success')
]   