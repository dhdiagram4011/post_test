#sign-in date input form

from django import forms
from .models import Join
from .models import Login
from .models import Gtran

class JoinForm(forms.ModelForm):
    class Meta:
        model = Join
        fields = ('name','email','password')


class LoginForm(forms.ModelForm):
    class Meta:
        model = Login
        fields = ('name','password')


class GtransForm(forms.ModelForm):
    class Meta:
        model = Gtran
        fields = ('asis','languages')


    




