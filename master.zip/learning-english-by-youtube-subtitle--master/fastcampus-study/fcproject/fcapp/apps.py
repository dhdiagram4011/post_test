from django.apps import AppConfig


class FcappConfig(AppConfig):
    name = 'fcapp'
