#from django.urls import path
#from . import views

#urlpatterns = [
#    path('', views.selecttest, name='selecttest'),
#]