#!/bin/bash
echo "hello, world! The time is $(date)."
