from flask_sqlalchemy import SQLAlchemy


db = SQLAlchemy()

#class rockplace(db.Model):
#    __tablename__ = 'rockplace'
#    id = db.Column(db.Integer, nullable=False, primary_key=True)
#    password = db.Column(db.String(100), nullable=False, default='')
#    userid = db.Column(db.String(100), nullable=False, default='')
#    username = db.Column(db.String(100), nullable=False, default='')
#    userdivision = db.Column(db.String(100), nullable=False, default='')
#    userofficetel = db.Column(db.String(100), nullable=False, default='')
#    usercellphone = db.Column(db.String(100), nullable=False, default='')
#    useremail = db.Column(db.String(100), nullable=False, default='')
#    useraddress = db.Column(db.String(100), nullable=False, default='')
#    userfloor = db.Column(db.String(100), nullable=False, default='')
#    usermanager = db.Column(db.String(100), nullable=False, default='')
#    userbirth = db.Column(db.String(100), nullable=False, default='')

class Rpemployee(db.Model):
    __tablename__ = 'rpemployee'
    id = db.Column(db.Integer, nullable=False, primary_key=True)
    userid = db.Column(db.String(200), nullable=False, default='')
    userapppw = db.Column(db.String(200), nullable=False, default='')
    employee_number = db.Column(db.String(200), nullable=False, default='')
    tel_nubmer = db.Column(db.String(200), nullable=False, default='')
    manager = db.Column(db.String(200), nullable=False, default='')
    depart = db.Column(db.String(200), nullable=False, default='')
    people_name = db.Column(db.String(200), nullable=False, default='')
    cell_number = db.Column(db.String(200), nullable=False, default='')
    floor = db.Column(db.String(200), nullable=False, default='')
    first_day = db.Column(db.String(200), nullable=False, default='')
    per_email = db.Column(db.String(200), nullable=False, default='')