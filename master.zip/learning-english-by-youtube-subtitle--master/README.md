###### Developer : rleahgud21764011@gmail.com

### > learning-english-by-youtube-subtitle

###### 1. 소개
####### 1-1) 회원 가입
####### 1-2) 로그인 
####### 1-3) 유투브 동영상 선택 후 유투브 자막을 뽑아서 자막을 번역
###### 2. 실행방법





 



 
