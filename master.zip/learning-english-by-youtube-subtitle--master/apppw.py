#Developer - dohyoung.kim@rockplace.co.kr
#initial Dev - 2019.06.03 by RPITS Team dohyoung.kim

import os
from flask import Flask
from flask import request
from flask import session
from flask import redirect
from flask import render_template
from models import db
from models import Rpemployee
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import Column
from flask_mysqldb import MySQL
#from forms import LoginForm
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)

@app.route('/send', methods=['GET','POST'])
def send():
    if request.method == 'GET':
        return render_template('res_send.html')
    else:
        userid = request.form.get('userid')
        userapppw = request.form.get('userapppw')
        employee_nubmer = request.form.get('employee_number')
        tel_number = request.form.get('tel_number')
        manager = request.form.get('manager')
        depart = request.form.get('depart')
        people_name = request.form.get('people_name')
        cell_number = request.form.get('cell_number')
        floor = request.form.get('floor')
        first_day = request.form.get('first_day')
        per_email = request.form.get('per_email')




        if not (userid and userapppw):
            return render_template('res_send.html') 
        
        rpemployee = Rpemployee()
        rpemployee.userid = userid
        #rpemployee.userapppw = generate_password_hash(userapppw)
        rpemployee.userapppw = userapppw
        rpemployee.employee_number = employee_nubmer
        rpemployee.tel_nubmer = tel_number
        rpemployee.manager = manager
        rpemployee.depart = depart
        rpemployee.people_name = people_name
        rpemployee.cell_number = cell_number
        rpemployee.floor = floor
        rpemployee.first_day = first_day
        rpemployee.per_email = per_email


        db.session.add(rpemployee)
        db.session.commit()

        return redirect('/first')
        

@app.route('/first')
def success():
    userid = session.get('userid', None)
    return render_template('in_success.html')

if __name__ == "__main__":
    basedir = os.path.abspath(os.path.dirname(__file__))
    dbfile = os.path.join(basedir,'db.mysql')

    app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql://root:k20504003@localhost:3306/apdb'
    app.config['SQLALCHEMY_COMMIT_ON_TEARDOWN'] = True
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

    db.init_app(app)
    db.app = app
    db.create_all()
    app.run(host='127.0.0.1', port=5001, debug=True)
